﻿using System;
using System.Collections.Generic;
using Rabobank.TechnicalTest.GCOB.DataAccess;
using Rabobank.TechnicalTest.GCOB.Domain;

namespace Rabobank.TechnicalTest.GCOB.ActionProvider
{

    public class CustomerAction : ICustomerAction
    {
        private readonly ICustomerRepository _memoryCustomerRepository;
        private readonly IAddressRepository _memoryAddressRepository;
        private readonly ICountryRepository _memoryCountryRepository;
        public CustomerAction(ICustomerRepository customerRepository, IAddressRepository addressRepository, ICountryRepository countryRepository)
        {
            _memoryCustomerRepository = customerRepository;
            _memoryAddressRepository = addressRepository;
            _memoryCountryRepository = countryRepository;
        }
        public IEnumerable<CustomerSummaryDto> Get()
        {
            throw new NotImplementedException();
        }

        public  CustomerDto AddCustomer(CustomerDto customerdto)
        {
            // In real scenarios we will be using statement with transactionscope
                 Customer _customer = new Customer();
                _customer.Id = _memoryCustomerRepository.GenerateIdentityAsync().Result;
                _customer.FirstName = customerdto.FirstName;
                _customer.LastName = customerdto.LastName;

                Address _address = new Address();
                _address.Id = _memoryAddressRepository.GenerateIdentityAsync().Result;
                _address.Street = customerdto.Street;
                _address.City = customerdto.City;
                _address.Postcode = customerdto.Postcode;
                _memoryAddressRepository.InsertAsync(_address);
                            
                _memoryCustomerRepository.InsertAsync(_customer);
            
            
            return customerdto;
        }

         public  CustomerSummaryDto GetById(int Id)
         {
            CustomerSummaryDto customerSummaryDto = new CustomerSummaryDto();
                      
                var customer = _memoryCustomerRepository.GetAsync(Id).Result;
                var address = _memoryAddressRepository.GetAsync(Id).Result;
                var country = _memoryCountryRepository.GetAsync(Id).Result;

                customerSummaryDto.Id = customer.Id;
                customerSummaryDto.FullName = customer.FirstName + ' ' + customer.LastName;
                customerSummaryDto.Street = address.Street;
                customerSummaryDto.City = address.City;
                customerSummaryDto.Postcode = address.Postcode;
                customerSummaryDto.Country = country.Name;
           
            return customerSummaryDto;
        }
    }
}
