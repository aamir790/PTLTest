﻿using Rabobank.TechnicalTest.GCOB.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Rabobank.TechnicalTest.GCOB.ActionProvider
{
    public interface ICustomerAction
    {

        public IEnumerable<CustomerSummaryDto> Get();

        public CustomerSummaryDto GetById(int Id);

        public CustomerDto AddCustomer(CustomerDto customerDto);
       
    }
}
