# gcob-technical-test

# Tasks
1. Call the Customer/POST to insert a customer into the repository
2. Call the Customer/GET to retrieve the inserted customer
3. Ensure test coverage and all tests pass

Please fork/clone the GitHub repo then send us a link to the solution in your own GitHub or zip the solution and email it to us
