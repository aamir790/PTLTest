﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Rabobank.TechnicalTest.GCOB.Domain
{
    public class CountryDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
