﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Rabobank.TechnicalTest.GCOB.Domain;
using Rabobank.TechnicalTest.GCOB.ActionProvider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Rabobank.TechnicalTest.GCOB.Controllers
{
    [ApiController]
    [Route("api/customer")]
    public class CustomerController : ControllerBase
    {
        private readonly ILogger<CustomerController> _logger;
        private readonly ICustomerAction _icustomerAction;


        public CustomerController(ILogger<CustomerController> logger, ICustomerAction customerAction)
        {
            _logger = logger;
            _icustomerAction = customerAction;
        }

        [HttpGet("{id}")]
        public CustomerSummaryDto GetCustomerById(int id)
        {
            return _icustomerAction.GetById(id);
        }
            
        [HttpPost]
        public CustomerDto AddCustomer([FromBody]CustomerDto customerDto)
        {
            return _icustomerAction.AddCustomer(customerDto);
        }
    }
}
