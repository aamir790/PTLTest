using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;
using Rabobank.TechnicalTest.GCOB.DataAccess;
using Rabobank.TechnicalTest.GCOB.Domain;
using Moq;
using System;
using Rabobank.TechnicalTest.GCOB.ActionProvider;
using Rabobank.TechnicalTest.GCOB.Controllers;
//using Castle.Core.Logging;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using System.ComponentModel.DataAnnotations;

namespace Rabobank.TechnicalTest.GCOB.Tests.Services
{
    [TestClass]
    public class CustomerControllerTest
    {
        private Mock<ICustomerAction> mockCustomerAction;
        private Mock<ILogger<CustomerController>> mockLogger;
        private CustomerController customerController;
        private CustomerDto customerDto;
        private CustomerSummaryDto customerSummaryDto;



        [TestInitialize]
        public void Initialize()
        {
            var customer = new Customer
            {
                Id = 1,
                FirstName = "Xiang",
                LastName = "Fred",
                AddressId = 1
            };

            var address = new Address
            {
                Id = 1,
                Street = "London Road",
                City = "Amsterdam",
                Postcode = "11M",
                CountryId = 1
            };

            var country = new Country
            {
                Id = 1,
                Name = "Netherlands"
            };

            var customerDto = new CustomerDto
            {
                Id = 1,
                FirstName = "Xiang",
                LastName = "Fred",
                Street = "London Road",
                City = "Amsterdam",
                Postcode = "11M",
                CountryId = 1
            };

            var customerSummaryDto = new CustomerSummaryDto
            {
                Id = 1,
                FullName = "Xiang Fred",
                Street = "London Road",
                City = "Amsterdam",
                Postcode = "11M",
                Country = "Netherlands"
            };

            this.mockCustomerAction = new Mock<ICustomerAction>();
            this.mockCustomerAction.Setup(x => x.AddCustomer (this.customerDto)).Returns(customerDto);
            this.mockCustomerAction.Setup(x => x.GetById(1)).Returns(customerSummaryDto);
            this.mockLogger = new Mock<ILogger<CustomerController>>();
        

            this.customerController = new CustomerController(mockLogger.Object, this.mockCustomerAction.Object);
            
        }


        [TestMethod]
        public async Task GivenHaveACustomer_AndICallAServiceToGetTheCustomer_ThenTheCustomerIsNotNull()
        {
            var result = this.customerController.GetCustomerById(1);
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public async Task GivenHaveACustomer_AndICallAServiceToGetTheCustomer_ThenTheCustomerNull()
        {
            var result = this.customerController.GetCustomerById(2);
            Assert.IsNull(result);
        }

        [TestMethod]
        public async Task GivenHaveACustomer_AndICallAServiceToGetTheCustomer_ThenTheCustomerIsReturned()
        {
            var result = this.customerController.GetCustomerById(1);
            Assert.AreEqual(result.Id, 1);
        }

        [TestMethod]
        public async Task GivenHaveACustomer_AndICallAServiceToAddCustomer_ThenTheCustomerIsReturned()
        {
            var result = this.customerController.AddCustomer(customerDto);
            Assert.AreEqual(result.Id, 1);
        }
    }
}