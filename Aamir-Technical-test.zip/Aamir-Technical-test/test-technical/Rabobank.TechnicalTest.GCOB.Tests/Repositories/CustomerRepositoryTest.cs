﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Rabobank.TechnicalTest.GCOB.Domain;
using Rabobank.TechnicalTest.GCOB.ActionProvider;
using System.Runtime.CompilerServices;

using System.Threading.Tasks;
using Rabobank.TechnicalTest.GCOB.DataAccess;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Rabobank.TechnicalTest.GCOB.Controllers;

namespace Rabobank.TechnicalTest.GCOB.Tests.Services
{
    [TestClass]
    public class CustomerRepositoryTest
    {
        private ILogger<CustomerController> logger;
        
        [TestInitialize]
        public void Initialize()
        {
            var serviceProvider = new ServiceCollection()
                .AddLogging()
                .BuildServiceProvider();

            var factory = serviceProvider.GetService<ILoggerFactory>();

            logger = factory.CreateLogger<CustomerController>();
        }


        [TestMethod]
        public async Task GivenHaveACustomer_AndIGetTheCustomerFromTheMemory_ThenTheCustomerIsRetrieved()
        {
        var customerRepository = new InMemoryCustomerRepository(logger);
            var result = customerRepository.GetAsync(1);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GivenHaveACustomer_InsertheCustomerinMemory_ThenTheCustomerIsRetrieved()
        {
            var customerRepository = new InMemoryCustomerRepository(logger);
            var customer = new Customer
            {
                Id = 2,
                FirstName = "Xiang",
                LastName = "Fred",
                AddressId = 1
            };
            var result = customerRepository.InsertAsync(customer);
            Assert.IsNotNull(result);
        }
    }
}
