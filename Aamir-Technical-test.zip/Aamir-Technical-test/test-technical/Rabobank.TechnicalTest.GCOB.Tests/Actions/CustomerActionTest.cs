﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;
using Rabobank.TechnicalTest.GCOB.Domain;
using Moq;
using System;
using Rabobank.TechnicalTest.GCOB.ActionProvider;
using Rabobank.TechnicalTest.GCOB.DataAccess;
using System.Net.Http.Headers;

namespace Rabobank.TechnicalTest.GCOB.Tests.Services
{
    [TestClass]
    public class CustomerActionTest
    {
        private Mock<ICustomerRepository> mockCustomerRepository;
        private Mock<IAddressRepository> mockAddressRepository;
        private Mock<ICountryRepository> mockCountryRepository;
        private ICustomerAction customerAction;


        [TestInitialize]
        public void Initialize()
        {
            var customer = new Customer
            {
                Id = 1,
                FirstName = "Xiang",
                LastName = "Fred",
                AddressId = 1
            };

            var address = new Address
            {
                Id = 1,
                Street = "London Road",
                City = "Amsterdam",
                Postcode = "11M",
                CountryId = 1
            };

            var country = new Country
            {
                Id = 1,
                Name = "Netherlands"
            };

            this.mockCustomerRepository = new Mock<ICustomerRepository>();
            this.mockAddressRepository = new Mock<IAddressRepository>();
            this.mockCountryRepository = new Mock<ICountryRepository>();

            this.mockCustomerRepository.Setup(x => x.GetAsync(1)).Returns(Task.FromResult(customer));
            this.mockCustomerRepository.Setup(x => x.InsertAsync(customer)).Returns(Task.FromResult(1));

            this.mockAddressRepository.Setup(x => x.GetAsync(1)).Returns(Task.FromResult(address));
            this.mockAddressRepository.Setup(x => x.InsertAsync(address)).Returns(Task.FromResult(1));

            this.mockCountryRepository.Setup(x => x.GetAsync(1)).Returns(Task.FromResult(country));
      

            this.customerAction = new CustomerAction(this.mockCustomerRepository.Object, this.mockAddressRepository.Object, this.mockCountryRepository.Object);

        }


        [TestMethod]
        public async Task GivenHaveACustomer_AndICallAServiceToGetTheCustomer_ThenTheCustomerIsReturned()
        {
            var result =  Task.FromResult(this.customerAction.GetById(1)).Result;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GivenInsertACustomer_AndICallAServiceToGetTheCustomer_ThenTheCustomerIsIOnSerted_AndTheCustomerIsReturned()
        {
            var customerDto = new CustomerDto
            {
                Id = 1,
                FirstName = "Xiang",
                LastName = "Fred",
                Street  = "London Road",
                City = "Amsterdam",
                Postcode ="11M",
                CountryId =1
            };
            var result = this.customerAction.AddCustomer(customerDto);
            Assert.IsNotNull(result);
        }
    }
}