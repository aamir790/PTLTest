﻿using Rabobank.TechnicalTest.GCOB.Domain;
using System.Threading.Tasks;

namespace Rabobank.TechnicalTest.GCOB.DataAccess
{
    public interface ICustomerRepository
    {
        Task<int> GenerateIdentityAsync();
        Task InsertAsync(Customer customer);
        Task<Customer> GetAsync(int identity);
        Task UpdateAsync(Customer customer);
    }
}
