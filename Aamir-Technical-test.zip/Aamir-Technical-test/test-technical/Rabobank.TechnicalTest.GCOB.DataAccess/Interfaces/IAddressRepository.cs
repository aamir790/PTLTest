﻿using Rabobank.TechnicalTest.GCOB.Domain;
using System.Threading.Tasks;

namespace Rabobank.TechnicalTest.GCOB.DataAccess
{
    public interface IAddressRepository
    {
        Task<int> GenerateIdentityAsync();
        Task InsertAsync(Address address);
        Task<Address> GetAsync(int identity);
        Task UpdateAsync(Address address);
    }
}
