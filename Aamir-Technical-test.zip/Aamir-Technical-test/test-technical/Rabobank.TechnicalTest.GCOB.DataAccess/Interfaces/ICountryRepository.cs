﻿using Rabobank.TechnicalTest.GCOB.Domain;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Rabobank.TechnicalTest.GCOB.DataAccess
{
    public interface ICountryRepository
    {
        Task<Country> GetAsync(int identity);
        Task<IEnumerable<Country>> GetAllAsync();
    }
}
